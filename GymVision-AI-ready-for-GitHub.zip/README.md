# GymVision AI

App de conteo de **burpees** y **kettlebell swings** con detección de pose en tiempo real usando la cámara (MediaPipe + Capacitor).

## Cómo generar el APK en 2 minutos (recomendado)

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. Sube **todo el contenido de esta carpeta** al repositorio.
3. Ve a la pestaña **Actions**.
4. Selecciona el workflow **Build Android APK**.
5. Haz clic en **Run workflow** → **Run workflow**.
6. Espera 3-6 minutos.
7. Cuando termine, descarga el artefacto **GymVision-AI-APK**.
8. Dentro está el archivo `app-debug.apk` listo para instalar en tu Android.

> Nota: En el teléfono activa "Instalar apps de orígenes desconocidos" / "Permitir de esta fuente".

## Compilar localmente (opcional)

Necesitas Node.js 20+ y Android Studio (o Android SDK + JDK 21).

```bash
npm install --legacy-peer-deps
npm run android:apk
```

El APK queda en:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Permisos incluidos
- Cámara (frontal y trasera)
- Mantener pantalla encendida durante el entrenamiento
- Internet (solo para descargar el modelo de pose la primera vez)

## Autor
Generado a partir del proyecto GymVision AI.
