import React from 'react';
import { Trash2 } from 'lucide-react';
import { WorkoutRecord } from '../types/workout';
import { formatDuration } from '../utils/audioAndStorage';

interface HistoryPanelProps {
  history: WorkoutRecord[];
  onDeleteEntry: (id: string) => void;
  onClearHistory: () => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({
  history,
  onDeleteEntry,
  onClearHistory,
}) => {
  return (
    <section
      aria-label="Historial de series"
      className="rounded-2xl bg-panel border border-slate-800/90 p-4 sm:p-5 space-y-4"
    >
      <div className="flex items-center justify-between gap-3 border-b border-slate-800 pb-3.5">
        <div>
          <h2 className="text-base font-bold text-white">Historial de series</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {history.length === 0
              ? 'Guardado localmente en este dispositivo'
              : `${history.length} ${history.length === 1 ? 'serie guardada' : 'series guardadas'} en este dispositivo`}
          </p>
        </div>

        {history.length > 0 && (
          <button
            type="button"
            onClick={onClearHistory}
            className="min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-bold text-rose-400 hover:bg-rose-500/10 transition cursor-pointer whitespace-nowrap shrink-0"
          >
            Borrar todo
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="text-sm text-slate-400 text-center py-8 leading-relaxed">
          Aún no hay series guardadas. Presiona{' '}
          <span className="text-slate-200 font-semibold">Guardar / Reset</span> al terminar tu serie
          para registrar tus repeticiones y ritmo.
        </div>
      ) : (
        <ul className="divide-y divide-slate-800/80 max-h-80 overflow-y-auto pr-1">
          {history.map((item) => {
            const dateObj = new Date(item.timestamp);
            const dateStr = dateObj.toLocaleDateString('es-ES', {
              day: 'numeric',
              month: 'short',
            });
            const timeStr = dateObj.toLocaleTimeString('es-ES', {
              hour: '2-digit',
              minute: '2-digit',
            });
            const isSwing = item.exercise === 'kettlebell_swings';
            const exerciseColor = isSwing ? 'text-cyber' : 'text-volt';
            const label = item.exerciseName || (isSwing ? 'Kettlebell Swings' : 'Burpees');

            return (
              <li
                key={item.id}
                className="py-3 first:pt-1 last:pb-1 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="flex items-baseline gap-2.5">
                    <span className="font-mono tabular-nums text-xl font-extrabold text-white">
                      {item.reps}
                    </span>
                    <span className={`text-sm font-bold truncate ${exerciseColor}`}>{label}</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
                    <span>{dateStr}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{timeStr}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right font-mono tabular-nums">
                    <div className="text-xs font-bold text-slate-200">
                      {formatDuration(item.durationSec)}
                    </div>
                    <div className="text-xs text-ember">{Number(item.paceRpm).toFixed(1)} RPM</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeleteEntry(item.id)}
                    aria-label={`Eliminar serie de ${item.reps} ${label}`}
                    className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
};
