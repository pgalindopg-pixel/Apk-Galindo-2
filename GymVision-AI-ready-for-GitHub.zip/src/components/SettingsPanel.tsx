import React from 'react';
import {
  AppSettings,
  AudioMode,
  SENSITIVITY_LABELS,
  SensitivityLevel,
} from '../types/workout';
import { getDynamicThresholds } from '../utils/poseEngine';

interface SettingsPanelProps {
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onResetDefaults: () => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  settings,
  onUpdateSettings,
  onResetDefaults,
}) => {
  const th = getDynamicThresholds(settings.sensitivityLevel);
  const sensitivityLabel = SENSITIVITY_LABELS[settings.sensitivityLevel];

  const thresholdSummary =
    settings.exercise === 'kettlebell_swings'
      ? `KB Swing: Bisagra < ${th.kbHingeMaxDeg}° · Extensión > ${th.kbLockoutMinDeg}° · Subida muñecas > ${Math.round(
          th.kbWristDriveRatio * 100
        )}%`
      : `Burpee: Bajada cadera > ${Math.round(
          th.burpeeDropRatio * 100
        )}% · Ángulo plancha < ${th.burpeeFloorTorsoMaxDeg}°`;

  return (
    <section
      aria-label="Ajustes de sensibilidad y audio"
      className="rounded-2xl bg-panel border border-slate-800/90 p-4 sm:p-5 space-y-5"
    >
      <div className="flex items-center justify-between gap-3 border-b border-slate-800 pb-3.5">
        <div>
          <h2 className="text-base font-bold text-white">Sensibilidad y audio</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Ajusta los umbrales biomecánicos y el sonido de cada repetición.
          </p>
        </div>
        <button
          type="button"
          onClick={onResetDefaults}
          className="min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-bold text-cyber hover:bg-cyber/10 transition cursor-pointer whitespace-nowrap shrink-0"
        >
          Restaurar
        </button>
      </div>

      {/* Detection Sensitivity */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <label htmlFor="slider-sensitivity" className="text-xs font-semibold text-slate-200">
            Sensibilidad de detección
          </label>
          <span className="font-mono text-xs font-bold text-volt">{sensitivityLabel}</span>
        </div>
        <input
          id="slider-sensitivity"
          type="range"
          min={1}
          max={3}
          step={1}
          value={settings.sensitivityLevel}
          onChange={(e) =>
            onUpdateSettings({
              sensitivityLevel: Number(e.target.value) as SensitivityLevel,
            })
          }
          className="gym-slider"
        />
        <div className="flex justify-between text-[11px] text-slate-400">
          <span>Baja (estricto)</span>
          <span>Media</span>
          <span>Alta (flexible)</span>
        </div>
        <p className="text-xs text-slate-400 font-mono tabular-nums pt-0.5">{thresholdSummary}</p>
      </div>

      <div className="border-t border-slate-800/80" />

      {/* Pose Confidence */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <label htmlFor="slider-confidence" className="text-xs font-semibold text-slate-200">
            Confianza mínima de pose
          </label>
          <span className="font-mono tabular-nums text-xs font-bold text-cyber">
            {settings.confidenceThreshold.toFixed(2)}
          </span>
        </div>
        <input
          id="slider-confidence"
          type="range"
          min={0.2}
          max={0.75}
          step={0.05}
          value={settings.confidenceThreshold}
          onChange={(e) =>
            onUpdateSettings({
              confidenceThreshold: parseFloat(e.target.value),
            })
          }
          className="gym-slider"
        />
        <p className="text-xs text-slate-400">
          Bájala si entrenas con poca luz; súbela si detecta objetos en el fondo.
        </p>
      </div>

      <div className="border-t border-slate-800/80" />

      {/* Audio Mode & Skeleton Toggle */}
      <div className="space-y-4">
        <div>
          <label
            htmlFor="select-audio-mode"
            className="block text-xs font-semibold text-slate-200 mb-2"
          >
            Retroalimentación sonora
          </label>
          <select
            id="select-audio-mode"
            value={settings.audioMode}
            onChange={(e) => onUpdateSettings({ audioMode: e.target.value as AudioMode })}
            className="w-full min-h-[44px] rounded-xl bg-obsidian border border-slate-700 text-white text-sm font-medium px-3.5 py-2 focus:outline-none focus:border-volt"
          >
            <option value="both">Voz en español + pitido sintetizado</option>
            <option value="voice">Solo voz en español (TTS)</option>
            <option value="beep">Solo pitido (Web Audio)</option>
            <option value="off">Silenciado</option>
          </select>
        </div>

        <label
          htmlFor="toggle-skeleton"
          className="flex items-center justify-between gap-3 min-h-[44px] cursor-pointer"
        >
          <div>
            <span className="block text-sm font-semibold text-slate-200">Dibujar esqueleto</span>
            <span className="block text-xs text-slate-400">
              Superpone articulaciones y huesos sobre el video
            </span>
          </div>
          <input
            id="toggle-skeleton"
            type="checkbox"
            checked={settings.drawSkeleton}
            onChange={(e) => onUpdateSettings({ drawSkeleton: e.target.checked })}
            className="w-5 h-5 accent-[#a3e635] rounded cursor-pointer shrink-0"
          />
        </label>
      </div>
    </section>
  );
};
