import {
  AppSettings,
  AudioMode,
  DEFAULT_SETTINGS,
  ExerciseId,
  STORAGE_KEYS,
  WorkoutRecord,
} from '../types/workout';

let sharedAudioCtx: AudioContext | null = null;

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      sensitivityLevel:
        parsed.sensitivityLevel === 1 || parsed.sensitivityLevel === 2 || parsed.sensitivityLevel === 3
          ? parsed.sensitivityLevel
          : DEFAULT_SETTINGS.sensitivityLevel,
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.warn('No se pudo guardar configuración:', err);
  }
}

export function loadHistory(): WorkoutRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as WorkoutRecord[]) : [];
  } catch {
    return [];
  }
}

export function saveHistory(records: WorkoutRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(records));
  } catch (err) {
    console.warn('No se pudo guardar historial:', err);
  }
}

export function formatDuration(totalSec: number): string {
  const sec = Math.max(0, Math.floor(totalSec));
  const mins = Math.floor(sec / 60);
  const rem = sec % 60;
  return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

export function computePaceRPM(repCount: number, elapsedSeconds: number): number {
  if (repCount <= 0 || elapsedSeconds <= 0) return 0;
  return Number(((repCount / elapsedSeconds) * 60).toFixed(1));
}

export function ensureAudioContext(): AudioContext | null {
  try {
    if (!sharedAudioCtx) {
      const AudioContextCtor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioContextCtor) {
        sharedAudioCtx = new AudioContextCtor();
      }
    }
    if (sharedAudioCtx && sharedAudioCtx.state === 'suspended') {
      void sharedAudioCtx.resume();
    }
    return sharedAudioCtx;
  } catch (err) {
    console.warn('AudioContext no disponible:', err);
    return null;
  }
}

export function playRepBeep(): void {
  try {
    const ctx = ensureAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(720, now);
    osc.frequency.exponentialRampToValueAtTime(1080, now + 0.11);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.24, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);
  } catch (err) {
    console.warn('Error de pitido:', err);
  }
}

export function speakRepSpanish(repNumber: number, exercise: ExerciseId): void {
  try {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const isFirst = repNumber === 1;
    const exName = exercise === 'burpees' ? 'burpees' : 'swings';
    const phrase = isFirst ? `1, ${exName}` : String(repNumber);
    const utter = new SpeechSynthesisUtterance(phrase);
    utter.lang = 'es-ES';
    utter.rate = 1.15;
    utter.pitch = 1.05;
    utter.volume = 1.0;
    window.speechSynthesis.speak(utter);
  } catch (err) {
    console.warn('Error en síntesis de voz:', err);
  }
}

export function triggerRepFeedback(
  repNumber: number,
  audioMode: AudioMode,
  exercise: ExerciseId
): void {
  if (audioMode === 'off') return;
  if (audioMode === 'beep' || audioMode === 'both') {
    playRepBeep();
  }
  if (audioMode === 'voice' || audioMode === 'both') {
    speakRepSpanish(repNumber, exercise);
  }
}
